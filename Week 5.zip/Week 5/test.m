f = @(x,y) x+y
sum(f([1:3],[:,1]))
J =3
for j = 1:J
    #dJdW = (G(j) - Y(j)) * G(j) * (1-G(j) * Fbar(K)
   j
end